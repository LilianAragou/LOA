using UnityEngine;
public class EvolutionCost : MonoBehaviour
{
    public int cost = 0;
}
